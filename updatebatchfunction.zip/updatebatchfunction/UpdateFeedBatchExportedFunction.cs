using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Text.Json;

namespace UpdateBatchFunction;

public class UpdateFeedBatchExportedFunction
{
    private readonly UpdateBatchSqlService          _sqlService;
    private readonly ILogger<UpdateFeedBatchExportedFunction> _log;

    public UpdateFeedBatchExportedFunction(
        UpdateBatchSqlService sqlService,
        ILogger<UpdateFeedBatchExportedFunction> log)
    {
        _sqlService = sqlService;
        _log        = log;
    }

    [Function("UpdateFeedBatchExported")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
    {
        _log.LogInformation("UpdateFeedBatchExported triggered.");

        try
        {
            // Read request body
            var body = await req.ReadAsStringAsync();

            if (string.IsNullOrEmpty(body))
            {
                _log.LogWarning("Request body is empty.");
                return CreateResponse(req, HttpStatusCode.BadRequest,
                    "Request body is required.");
            }

            // Deserialize request
            var request = JsonSerializer.Deserialize<UpdateBatchRequest>(body,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            if (request == null || request.FeedBatchFileId == Guid.Empty)
            {
                _log.LogWarning("Invalid or missing FeedBatchFileId.");
                return CreateResponse(req, HttpStatusCode.BadRequest,
                    "Valid FeedBatchFileId is required.");
            }

            _log.LogInformation($"Updating FeedBatchFileId: {request.FeedBatchFileId}");

            // Call Sp_UpdateFeedBatchExported
            await _sqlService.UpdateFeedBatchExportedAsync(request.FeedBatchFileId);

            _log.LogInformation(
                $"FeedBatchFileId: {request.FeedBatchFileId} marked as Exported.");

            return CreateResponse(req, HttpStatusCode.OK,
                $"FeedBatchFileId {request.FeedBatchFileId} updated to Exported.");
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "UpdateFeedBatchExported failed.");
            return CreateResponse(req, HttpStatusCode.InternalServerError,
                "An error occurred while updating the batch status.");
        }
    }

    private static HttpResponseData CreateResponse(
        HttpRequestData req, HttpStatusCode statusCode, string message)
    {
        var response = req.CreateResponse(statusCode);
        response.Headers.Add("Content-Type", "application/json");
        response.WriteString(JsonSerializer.Serialize(new { message }));
        return response;
    }
}
