using Microsoft.Data.SqlClient;
using System.Data;

namespace UpdateBatchFunction;

public class UpdateBatchSqlService
{
    private readonly string _connectionString;

    public UpdateBatchSqlService()
    {
        _connectionString = Environment.GetEnvironmentVariable("SQL_CONNECTION_STRING")
            ?? throw new InvalidOperationException("SQL_CONNECTION_STRING is not configured.");
    }

    // Calls Sp_UpdateFeedBatchExported
    // Step 1: Updates FeedBatchFile.Status = Exported
    // Step 2: Updates DocumentReview.IsExported = 1
    //         JOIN via FeedBatchFileDetails.ProviderAttachmentID
    public async Task UpdateFeedBatchExportedAsync(Guid feedBatchFileId)
    {
        using SqlConnection conn = new(_connectionString);
        await conn.OpenAsync();

        using SqlCommand cmd = new("dbo.Sp_UpdateFeedBatchExported", conn);
        cmd.CommandType    = CommandType.StoredProcedure;
        cmd.CommandTimeout = 60;

        cmd.Parameters.AddWithValue("@FeedBatchFileId", feedBatchFileId);

        await cmd.ExecuteNonQueryAsync();
    }
}
