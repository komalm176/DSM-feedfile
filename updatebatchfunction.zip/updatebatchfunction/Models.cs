namespace UpdateBatchFunction;

public class UpdateBatchRequest
{
    public Guid FeedBatchFileId { get; set; }
}
