namespace FeedFileFunction;

public class FeedRecord
{
    public string ProviderAttachmentId { get; set; } = string.Empty;
    public string ReviewStatus         { get; set; } = string.Empty;
    public string RejectReason         { get; set; } = string.Empty;
}

public class FeedBatchResult
{
    public Guid             FeedBatchFileId { get; set; }
    public List<FeedRecord> Records         { get; set; } = new();
}

public class FeedBatchMessage
{
    public string FeedBatchFileId { get; set; } = string.Empty;
    public string BlobPath        { get; set; } = string.Empty;
    public string FileName        { get; set; } = string.Empty;
}
