using Microsoft.Data.SqlClient;
using System.Data;

namespace FeedFileFunction;

public class FeedFileSqlService
{
    private readonly string _connectionString;

    public FeedFileSqlService()
    {
        _connectionString = Environment.GetEnvironmentVariable("SQL_CONNECTION_STRING")
            ?? throw new InvalidOperationException("SQL_CONNECTION_STRING is not configured.");
    }

    // Step 1: Call Sp_GetBatchDetails
    // - Checks INIT guard
    // - Fetches TOP 1000 from DocumentReview (StatusId IN 1,3 and IsExported=0)
    // - Inserts into FeedBatchFile (Status=INIT) and FeedBatchFileDetails
    // - Returns FeedBatchFileId + records
    public async Task<FeedBatchResult?> GetBatchDetailsAsync()
    {
        using SqlConnection conn = new(_connectionString);
        await conn.OpenAsync();

        using SqlCommand cmd = new("dbo.Sp_GetBatchDetails", conn);
        cmd.CommandType    = CommandType.StoredProcedure;
        cmd.CommandTimeout = 120;

        SqlParameter batchIdParam = new("@FeedBatchFileId", SqlDbType.UniqueIdentifier)
        {
            Direction = ParameterDirection.Output
        };
        cmd.Parameters.Add(batchIdParam);

        List<FeedRecord> records = new();

        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
        {
            while (await reader.ReadAsync())
            {
                records.Add(new FeedRecord
                {
                    ProviderAttachmentId = reader["ProviderAttachmentID"].ToString()!,
                    ReviewStatus         = reader["ReviewStatus"].ToString()!,
                    RejectReason         = reader["RejectReason"]?.ToString() ?? string.Empty
                });
            }
        }

        // SP returns null BatchId if INIT batch already exists
        if (batchIdParam.Value == DBNull.Value || batchIdParam.Value == null)
            return null;

        return new FeedBatchResult
        {
            FeedBatchFileId = (Guid)batchIdParam.Value,
            Records         = records
        };
    }

    // Step 4: Call Sp_UpdateFeedBatchFileCreated
    // - Updates FeedBatchFile: FileName, BlobPath, Status=Created, UpdatedDateTime
    public async Task UpdateFeedBatchFileCreatedAsync(
        Guid   feedBatchFileId,
        string fileName,
        string blobPath)
    {
        using SqlConnection conn = new(_connectionString);
        await conn.OpenAsync();

        using SqlCommand cmd = new("dbo.Sp_UpdateFeedBatchFileCreated", conn);
        cmd.CommandType    = CommandType.StoredProcedure;
        cmd.CommandTimeout = 60;

        cmd.Parameters.AddWithValue("@FeedBatchFileId", feedBatchFileId);
        cmd.Parameters.AddWithValue("@FileName",        fileName);
        cmd.Parameters.AddWithValue("@BlobPath",        blobPath);

        await cmd.ExecuteNonQueryAsync();
    }
}
