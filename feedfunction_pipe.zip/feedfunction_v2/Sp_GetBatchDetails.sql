CREATE OR ALTER PROCEDURE dbo.Sp_GetBatchDetails
    @FeedBatchFileId UNIQUEIDENTIFIER OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    -- Guard: Skip if batch is INIT or Created (not yet exported)
    -- Prevents duplicate batch if Service Bus publish fails after blob upload
    IF EXISTS (
        SELECT 1 FROM dbo.FeedBatchFile
        WHERE Status IN ('INIT', 'Created')
    )
    BEGIN
        SET @FeedBatchFileId = NULL;
        RETURN;
    END

    SET @FeedBatchFileId = NEWID();

    -- Fetch TOP 1000 unprocessed reviewed records
    SELECT TOP 1000
        dr.ProviderAttachmentID,
        drs.Status              AS ReviewStatus,
        drrr.RejectReason       AS RejectReason
    INTO #TempBatch
    FROM dbo.DocumentReview dr
    INNER JOIN dbo.DocumentReviewStatus drs
        ON dr.DocumentReviewStatusId = drs.DocumentReviewStatusId
    LEFT JOIN dbo.DocumentReviewRejectReason drrr
        ON dr.DocumentRejectReasonId = drrr.DocumentRejectReasonId
    WHERE dr.IsExported = 0
      AND dr.DocumentReviewStatusId IN (1, 3)
    ORDER BY dr.CreatedDateTime ASC;

    -- Insert batch header into FeedBatchFile
    INSERT INTO dbo.FeedBatchFile (
        FeedBatchFileId,
        Status,
        RecordCount,
        RetryCount,
        CreatedDateTime,
        UpdatedDateTime,
        [User]
    )
    VALUES (
        @FeedBatchFileId,
        'INIT',
        (SELECT COUNT(*) FROM #TempBatch),
        0,
        GETUTCDATE(),
        GETUTCDATE(),
        'Sp_GetBatchDetails'
    );

    -- Insert detail records into FeedBatchFileDetails
    INSERT INTO dbo.FeedBatchFileDetails (
        FeedBatchFileId,
        ProviderAttachmentID,
        CreatedDateTime
    )
    SELECT
        @FeedBatchFileId,
        ProviderAttachmentID,
        GETUTCDATE()
    FROM #TempBatch;

    -- Return records to Azure Function
    SELECT
        @FeedBatchFileId    AS FeedBatchFileId,
        ProviderAttachmentID,
        ReviewStatus,
        RejectReason
    FROM #TempBatch;

    DROP TABLE #TempBatch;
END
