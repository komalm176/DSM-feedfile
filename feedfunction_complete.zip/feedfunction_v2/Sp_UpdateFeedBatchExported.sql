CREATE OR ALTER PROCEDURE dbo.Sp_UpdateFeedBatchExported
    @FeedBatchFileId UNIQUEIDENTIFIER
AS
BEGIN
    SET NOCOUNT ON;

    -- Step 1: Update FeedBatchFile status to Exported
    UPDATE dbo.FeedBatchFile
    SET
        Status          = 'Exported',
        UpdatedDateTime = GETUTCDATE(),
        [User]          = 'FeedFileLogicApp'
    WHERE FeedBatchFileId = @FeedBatchFileId;

    IF @@ROWCOUNT = 0
    BEGIN
        RAISERROR('FeedBatchFile record not found for FeedBatchFileId: %s', 16, 1,
            @FeedBatchFileId);
        RETURN;
    END

    -- Step 2: Update IsExported = 1 in DocumentReview
    -- JOIN FeedBatchFileDetails to get ProviderDocumentsId for this batch
    UPDATE dr
    SET
        dr.IsExported       = 1,
        dr.UpdatedDateTime  = GETUTCDATE(),
        dr.[User]           = 'FeedFileLogicApp'
    FROM dbo.DocumentReview dr
    INNER JOIN dbo.FeedBatchFileDetails fbfd
        ON dr.ProviderDocumentsId = fbfd.ProviderAttachmentID
    WHERE fbfd.FeedBatchFileId = @FeedBatchFileId;

END
