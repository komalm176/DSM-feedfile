using Azure.Storage.Blobs;
using System.Text;

namespace FeedFileFunction;

public class FeedFileBlobService
{
    private readonly BlobServiceClient _blobServiceClient;
    private const string ContainerName = "feed-export";

    public FeedFileBlobService()
    {
        _blobServiceClient = new BlobServiceClient(
            Environment.GetEnvironmentVariable("BLOB_CONNECTION_STRING")
            ?? throw new InvalidOperationException("BLOB_CONNECTION_STRING is not configured."));
    }

    public async Task<string> UploadFeedFileAsync(
        Guid   feedBatchFileId,
        string fileName,
        string fileContent)
    {
        var containerClient = _blobServiceClient.GetBlobContainerClient(ContainerName);
        await containerClient.CreateIfNotExistsAsync();

        // BlobPath: {FeedBatchFileId}/{FileName}
        var blobPath   = $"{feedBatchFileId}/{fileName}";
        var blobClient = containerClient.GetBlobClient(blobPath);

        var bytes = Encoding.UTF8.GetBytes(fileContent);
        using var stream = new MemoryStream(bytes);

        await blobClient.UploadAsync(stream, overwrite: true);

        return blobPath;
    }
}
