using Microsoft.Data.SqlClient;
using System.Data;

namespace FeedFileFunction;

public class FeedFileSqlService
{
    private readonly string _connectionString;

    public FeedFileSqlService()
    {
        _connectionString = Environment.GetEnvironmentVariable("SQL_CONNECTION_STRING")
            ?? throw new InvalidOperationException("SQL_CONNECTION_STRING is not configured.");
    }

    public async Task<FeedBatchResult?> GetBatchDetailsAsync()
    {
        using SqlConnection conn = new(_connectionString);
        await conn.OpenAsync();

        using SqlCommand cmd = new("dbo.Sp_GetBatchDetails", conn);
        cmd.CommandType    = CommandType.StoredProcedure;
        cmd.CommandTimeout = 120;

        SqlParameter batchIdParam = new("@FeedBatchFileId", SqlDbType.UniqueIdentifier)
        {
            Direction = ParameterDirection.Output
        };
        cmd.Parameters.Add(batchIdParam);

        List<FeedRecord> records = new();

        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
        {
            while (await reader.ReadAsync())
            {
                records.Add(new FeedRecord
                {
                    ProviderId        = reader["ProviderId"]?.ToString()        ?? string.Empty,
                    ProviewAssocId    = reader["ProviewAssocId"]?.ToString()    ?? string.Empty,
                    ProviewDocId      = reader["ProviewDocId"]?.ToString()      ?? string.Empty,
                    DocumentumId      = reader["DocumentumId"]?.ToString()      ?? string.Empty,
                    ReviewStatus      = reader["ReviewStatus"]?.ToString()      ?? string.Empty,
                    DocumentType      = reader["DocumentType"]?.ToString()      ?? string.Empty,
                    State             = reader["State"]?.ToString(),
                    ReviewedDateTime  = reader["ReviewedDateTime"]?.ToString()  ?? string.Empty,
                    ExpirationDate    = reader["ExpirationDate"]?.ToString(),
                    RejectReason      = reader["RejectReason"]?.ToString()      ?? string.Empty,
                    Ingestionsource   = reader["Ingestionsource"]?.ToString()   ?? string.Empty,
                    WqmIncidentNumber = reader["WqmIncidentNumber"]?.ToString()
                });
            }
        }

        if (batchIdParam.Value == DBNull.Value || batchIdParam.Value == null)
            return null;

        return new FeedBatchResult
        {
            FeedBatchFileId = (Guid)batchIdParam.Value,
            Records         = records
        };
    }

    public async Task UpdateFeedBatchFileCreatedAsync(
        Guid   feedBatchFileId,
        string fileName,
        string blobPath)
    {
        using SqlConnection conn = new(_connectionString);
        await conn.OpenAsync();

        using SqlCommand cmd = new("dbo.Sp_UpdateFeedBatchFileCreated", conn);
        cmd.CommandType    = CommandType.StoredProcedure;
        cmd.CommandTimeout = 60;

        cmd.Parameters.AddWithValue("@FeedBatchFileId", feedBatchFileId);
        cmd.Parameters.AddWithValue("@FileName",        fileName);
        cmd.Parameters.AddWithValue("@BlobPath",        blobPath);

        await cmd.ExecuteNonQueryAsync();
    }
}
