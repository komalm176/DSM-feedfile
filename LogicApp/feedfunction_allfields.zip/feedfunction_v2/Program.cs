using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using FeedFileFunction;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices(services =>
    {
        services.AddSingleton<FeedFileSqlService>();
        services.AddSingleton<FeedFileBlobService>();
        services.AddSingleton<FeedFileServiceBusService>();
    })
    .Build();

host.Run();
