using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace FeedFileFunction;

public class FeedFileTimerFunction
{
    private readonly FeedFileSqlService        _sqlService;
    private readonly FeedFileBlobService       _blobService;
    private readonly FeedFileServiceBusService _serviceBusService;
    private readonly ILogger<FeedFileTimerFunction> _log;

    public FeedFileTimerFunction(
        FeedFileSqlService        sqlService,
        FeedFileBlobService       blobService,
        FeedFileServiceBusService serviceBusService,
        ILogger<FeedFileTimerFunction> log)
    {
        _sqlService        = sqlService;
        _blobService       = blobService;
        _serviceBusService = serviceBusService;
        _log               = log;
    }

    // Runs every 4 hours
    [Function("FeedFileTimerFunction")]
    public async Task Run([TimerTrigger("%FEED_TIMER_SCHEDULE%")] TimerInfo timer)
    {
        _log.LogInformation($"Feed File Timer triggered at: {DateTime.UtcNow}");

        try
        {
            // ── Step 1 ──────────────────────────────────────────────────────
            // Call Sp_GetBatchDetails
            // Checks INIT guard, fetches 1000 records, inserts FeedBatchFile
            // (Status=INIT) and FeedBatchFileDetails
            var batchResult = await _sqlService.GetBatchDetailsAsync();

            if (batchResult == null)
            {
                _log.LogWarning("Batch already in INIT state. Skipping this run.");
                return;
            }

            if (!batchResult.Records.Any())
            {
                _log.LogInformation("No eligible records found. Exiting.");
                return;
            }

            _log.LogInformation(
                $"Batch created | FeedBatchFileId: {batchResult.FeedBatchFileId} " +
                $"| Records: {batchResult.Records.Count}");

            // ── Step 2 ──────────────────────────────────────────────────────
            // Generate feed text file in memory
            // Format per line: ProviderAttachmentId,ReviewStatus,'RejectReason'
            var (fileContent, fileName) = FeedFileGenerator.Generate(batchResult.Records);
            _log.LogInformation($"Feed file generated: {fileName}");

            // ── Step 3 ──────────────────────────────────────────────────────
            // Upload text file to Blob container: feed-export
            // BlobPath: {FeedBatchFileId}/{FileName}
            var blobPath = await _blobService.UploadFeedFileAsync(
                batchResult.FeedBatchFileId, fileName, fileContent);
            _log.LogInformation($"Blob uploaded: {blobPath}");

            // ── Step 4 ──────────────────────────────────────────────────────
            // Call Sp_UpdateFeedBatchFileCreated
            // Updates FeedBatchFile: FileName, BlobPath, Status=Created
            await _sqlService.UpdateFeedBatchFileCreatedAsync(
                batchResult.FeedBatchFileId, fileName, blobPath);
            _log.LogInformation("FeedBatchFile status updated to Created.");

            // ── Step 5 ──────────────────────────────────────────────────────
            // Publish message to Service Bus
            // Payload: FeedBatchFileId, BlobPath, FileName
            await _serviceBusService.PublishFeedBatchMessageAsync(
                batchResult.FeedBatchFileId, blobPath, fileName);
            _log.LogInformation("Message published to Service Bus successfully.");
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Feed File Timer Function failed.");
            throw; // rethrow so Azure Functions runtime logs the failure
        }
    }
}
