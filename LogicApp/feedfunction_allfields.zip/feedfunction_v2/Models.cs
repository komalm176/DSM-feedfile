namespace FeedFileFunction;

public class FeedRecord
{
    public string  ProviderId          { get; set; } = string.Empty;
    public string  ProviewAssocId      { get; set; } = string.Empty;
    public string  ProviewDocId        { get; set; } = string.Empty;
    public string  DocumentumId        { get; set; } = string.Empty;
    public string  ReviewStatus        { get; set; } = string.Empty;
    public string  DocumentType        { get; set; } = string.Empty;
    public string? State               { get; set; }
    public string  ReviewedDateTime    { get; set; } = string.Empty;
    public string? ExpirationDate      { get; set; }
    public string  RejectReason        { get; set; } = string.Empty;
    public string  Ingestionsource     { get; set; } = string.Empty;
    public string? WqmIncidentNumber   { get; set; }
}

public class FeedBatchResult
{
    public Guid             FeedBatchFileId { get; set; }
    public List<FeedRecord> Records         { get; set; } = new();
}

public class FeedBatchMessage
{
    public string FeedBatchFileId { get; set; } = string.Empty;
    public string BlobPath        { get; set; } = string.Empty;
    public string FileName        { get; set; } = string.Empty;
}
