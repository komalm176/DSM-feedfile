using Azure.Messaging.ServiceBus;
using System.Text.Json;

namespace FeedFileFunction;

public class FeedFileServiceBusService
{
    private readonly ServiceBusClient _client;
    private readonly string           _queueName;

    public FeedFileServiceBusService()
    {
        _client = new ServiceBusClient(
            Environment.GetEnvironmentVariable("SERVICE_BUS_CONNECTION_STRING")
            ?? throw new InvalidOperationException("SERVICE_BUS_CONNECTION_STRING is not configured."));

        _queueName = Environment.GetEnvironmentVariable("SERVICE_BUS_QUEUE_NAME")
            ?? throw new InvalidOperationException("SERVICE_BUS_QUEUE_NAME is not configured.");
    }

    public async Task PublishFeedBatchMessageAsync(
        Guid   feedBatchFileId,
        string blobPath,
        string fileName)
    {
        await using var sender = _client.CreateSender(_queueName);

        var message = new FeedBatchMessage
        {
            FeedBatchFileId = feedBatchFileId.ToString(),
            BlobPath        = blobPath,
            FileName        = fileName
        };

        var json          = JsonSerializer.Serialize(message);
        var serviceBusMsg = new ServiceBusMessage(json)
        {
            ContentType = "application/json",
            MessageId   = feedBatchFileId.ToString()  // idempotency
        };

        await sender.SendMessageAsync(serviceBusMsg);
    }
}
