using System.Text;

namespace FeedFileFunction;

public static class FeedFileGenerator
{
    public static (string fileContent, string fileName) Generate(List<FeedRecord> records)
    {
        var sb = new StringBuilder();

        // Header row with pipe delimiter - matches client feed file format
        sb.AppendLine(
            "provider_id|proview_associated_entity_id|proview_document_entity_id|" +
            "documentum_id|status|doc_type|State|datetime|expiration_date|" +
            "reject_reason|ingestion_source|wqm_incident_number");

        foreach (var record in records)
        {
            sb.AppendLine(
                $"{record.ProviderId}|" +
                $"{record.ProviewAssocId}|" +
                $"{record.ProviewDocId}|" +
                $"{record.DocumentumId}|" +
                $"{record.ReviewStatus}|" +
                $"{record.DocumentType}|" +
                $"{record.State ?? string.Empty}|" +
                $"{record.ReviewedDateTime}|" +
                $"{record.ExpirationDate ?? string.Empty}|" +
                $"{record.RejectReason}|" +
                $"{record.Ingestionsource}|" +
                $"{record.WQMIncidentNumber ?? string.Empty}");
        }

        // File naming convention: FeedFromEDM_Portal_yyyyMMdd_HHmmss.csv
        var fileName = $"FeedFromEDM_Portal_{DateTime.UtcNow:yyyyMMdd_HHmmss}.csv";

        return (sb.ToString(), fileName);
    }
}
